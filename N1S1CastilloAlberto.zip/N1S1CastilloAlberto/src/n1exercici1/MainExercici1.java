package n1exercici1;

public class MainExercici1 {

	public static void main(String[] args) {
		
		InstrumentoPercusion tambor = new InstrumentoPercusion("tambor", 125);
		InstrumentoCuerda guitarra = new InstrumentoCuerda("guitarrar", 250);
		InstrumentoViento flauta = new InstrumentoViento("flauta", 90);
		
		System.out.println(flauta);
		
				

	}

}
